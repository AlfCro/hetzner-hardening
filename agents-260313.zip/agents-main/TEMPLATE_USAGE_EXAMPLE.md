# Template Usage Example

This file shows how the generic agent-workflow template introduced in commit `b62fdadd1242d39d37a055b33d8c876435ea1bb0` was used in this repository. The goal is not to explain the code in detail. The goal is to show the work process with concrete examples: start with skeleton docs, replace them with real project context, introduce a migration plan, revise the plan when new information appears, and then implement the work in small steps. This example now includes both the repository changes and the human prompt flow that produced them.

This example comes from the `canvas/LTI/bff` repository and covers the commit range from `b62fdadd1242d39d37a055b33d8c876435ea1bb0` through the current branch head at the time of writing. Readers who want more detail should inspect the repository history together with these files:

- `PROJECT.md`
- `WORKPLAN.md`
- `LTI_UPGRADE_PLAN.md`
- `LTI13_CANVAS_ROLLOUT_CHECKLIST.md`
- `README.md`
- `LESSONS.md`
- `TEMPLATE_USAGE_EXAMPLE.md`

At a high level, this example spans:

- 17 commits
- 35 changed files
- about 3,081 inserted lines and 182 deleted lines

That scale matters because it shows this was not a single small prompt-result pair. It was a sustained documentation, planning, implementation, and rollout-preparation effort.

## 1. Start with generic skeleton files

Commit `b62fdadd` added the process template files:

- `AGENTS.md`
- `CLAUDE.md`
- `GEMINI.md`
- `LESSONS.md`
- `PROJECT.md`
- `WORKPLAN.md`

At that point, the important markdown files were still placeholders.

- `PROJECT.md` contained headings like `[Project Name]`, `[Brief description of the project.]`, and a generic tech stack table.
- `WORKPLAN.md` contained only three generic phases: setup, implementation, and validation.
- `LESSONS.md` only contained the append-only format and severity guidance.

That is the template stage: create the structure first so the project has a place for context, planning, and accumulated lessons.

## 2. Fill the skeleton with real project context

Commit `8207fca` turned the empty structure into useful project documentation.

- `PROJECT.md` was filled with the real system overview, architecture, tech stack, constraints, authentication plan, and roadmap.
- `WORKPLAN.md` was changed from generic phases to a short status view with completed work and current focus.
- `README.md` was corrected so the docs matched the real codebase and configuration.

The initial population of the template was done with **Claude Opus 4.6** in max-effort mode using this prompt:

> Look at this solution and the markdown files that we have. Update them accordingly.

This is the first practical use of the template: the generic files stop being placeholders and become shared project memory.

## 3. Add a focused transition plan

Commit `679a9a5` added `LTI_UPGRADE_PLAN.md`. This is the second stage of the template in practice: when a change is large enough, keep the general project context in `PROJECT.md`, but create a separate plan for the transition itself.

In this repository, that meant documenting the move from LTI 1.0/1.1 toward LTI 1.3. The plan described:

- why the migration was needed
- a phased approach instead of a flag-day rewrite
- file and middleware changes at a high level
- environment variables and Canvas registration needs
- testing and rollback strategy
- concrete steps tracked as checkboxes so the plan could double as an execution checklist

This is the point where the documentation process moved from "what this repo is" to "how this repo will change."

The initial workplan was also created with **Claude Opus 4.6** in max-effort mode, through a short sequence of user prompts:

1. `In this repo, I want to examine whether we can and should move to a newer LTI version. We work against Canvas LMS. What would you propose?`
2. `Before that, I must be clear. We don't need any bidirectionality, but we do need ways to serve administrative support systems inside the host system. We have four tools: two purely administrative from a subaccount or course context, one for teachers where they can pick out reports, and one for course archiving.`
3. `Please make an implementation plan of this.`
4. `This plan, save it as md.`
5. `commit`

That sequence produced the first explicit migration plan as a markdown artifact, rather than leaving it as chat-only output.

## 4. Let the plan change when reality changes

The example is useful because the plan did not stay static.

- Commit `9ef38e5` updated `AGENTS.md` so future sessions would explicitly refer to the upgrade plan.
- Commit `67f74c4` clarified that LTI 1.3 was only a future option, not current active scope at that moment.
- Commit `bea9331` changed the plan again after a concrete discovery: Canvas did not expose `oauth_signature_method` in a way that made a SHA-256-first rollout meaningful, so the plan was updated to go directly toward LTI 1.3 dual-mode support.

This is an important part of the template usage: planning documents are expected to change when assumptions are proven wrong or incomplete.

There was also a corresponding human prompt sequence around those documentation updates:

1. `refer to it in AGENTS.md`
2. `commit`
3. `So change the plan to make us implement 1.3 instead. Don't implement it, just change the md files.`

That last prompt is especially important for the example. It shows a clean separation between:

- changing the plan
- changing the code

In this case, the markdown was deliberately corrected first, before continuing with implementation.

## 5. Implement the plan in narrow steps

After the planning docs were in place, the implementation work landed in focused commits rather than one large rewrite.

The implementation phase was done with **Codex 5.4 xhigh**. The human workflow was deliberately simple:

1. Start with a prompt like `Read the implementation plan in LTI_UPGRADE_PLAN.md and act on it.`
2. Let the agent complete the next logical slice.
3. Review the result.
4. When the slice looked correct, answer `yes` to the commit question.
5. Run `/clear`.
6. Prompt `continue`.
7. Repeat the loop for the next slice.

That loop matters for the example because it shows that the plan file was not just a planning artifact. It became the handoff document that allowed implementation to continue across multiple short agent sessions without re-explaining the whole migration every time.

An important detail is that `LTI_UPGRADE_PLAN.md` functioned as a living checklist during this phase. The implementation steps were tracked with checkboxes, and those checkboxes were updated in the iterations as slices were completed or re-scoped. In practice, the loop was not only:

- review
- commit
- `/clear`
- `continue`

It was also:

- update the plan status
- let the next session continue from the updated checklist

| Commit | High-level step | Example of what changed |
| --- | --- | --- |
| `5de9de9` | First migration slice | Added the dual-mode LTI 1.3 launch flow alongside LTI 1.1 and updated the main docs to describe the new state |
| `7a82fe1` | Compatibility follow-up | Adjusted LTI 1.3 role handling so existing LTI 1.1-era expectations still worked |
| `7ca976c` | Reliability follow-up | Added JWKS caching so LTI 1.3 launches did not depend on a network fetch every time |
| `455f86d` | Security follow-up | Tightened launch validation beyond signature checking alone |
| `10f0c4a` | Frontend integration follow-up | Preserved frontend asset loading when the launch path moved under `/lti13/launch` |
| `8092bd6` | Final compatibility pass so far | Normalized the `roles` field itself for frontend compatibility |
| `0426a19` | Legacy compatibility follow-up | Mapped more LTI 1.3 claims into the legacy launch fields that older tools still expect |
| `4333fd6` | Status and documentation follow-up | Updated the docs to say the main LTI 1.3 implementation slice was complete and rollout work was now the active focus |
| `6500435` | Rollout preparation follow-up | Added `LTI13_CANVAS_ROLLOUT_CHECKLIST.md` as a dedicated operational checklist for Canvas registration and environment-by-environment rollout |
| `0670745` | Operational clarification follow-up | Refined the rollout checklist so hosted configuration and local configuration sources were clearly separated |

The pattern is the important thing:

- the plan identified the direction
- the plan also tracked execution status through checkboxes
- the implementation landed in increments
- each increment could be reviewed and committed independently
- `/clear` plus `continue` allowed the next session to resume from the documented plan instead of a long remembered chat state
- each increment answered a concrete compatibility, reliability, security, or integration issue

## 6. Keep the docs synchronized with the implementation

Another concrete lesson from this repository is that the plan file was not left behind once coding started.

The implementation commits repeatedly updated:

- `PROJECT.md` to reflect the current architecture and active roadmap
- `README.md` to reflect setup and behavior that changed
- `LTI_UPGRADE_PLAN.md` to reflect the current implementation status and revised design decisions
- `LTI13_CANVAS_ROLLOUT_CHECKLIST.md` to track the operational rollout work after the main code slice was in place
- `LESSONS.md` to record discoveries that should influence later work

Examples recorded in `LESSONS.md` include:

- LTI 1.3 must be introduced in dual mode, not by removing LTI 1.1 immediately
- legacy `roles` and `ext_roles` compatibility matters more than raw protocol purity
- Canvas JWKS should be cached
- a valid signature is not enough for launch acceptance
- frontend asset paths can break when the launch URL changes

This is what turns the template into a working process rather than a one-time documentation exercise.

## 7. What this example demonstrates

From `b62fdadd` onward, the markdown workflow in this repository looked like this:

1. Add generic skeleton files for project memory, planning, and lessons learned.
2. Populate those files with real context using an explicit documentation pass.
3. Capture the migration idea as a dedicated markdown plan once the problem is understood well enough.
4. Refine the plan with follow-up prompts that narrow the requirements.
5. Revise the plan when new information changes the best approach, even if that means discarding an earlier phase.
6. Turn the saved plan into a checklist with status markers, not just prose.
7. Use the saved plan as the handoff document for implementation sessions.
8. Implement the work in reviewable steps instead of one large change.
9. Split out a separate rollout checklist when the work moves from code changes to environment-by-environment adoption.
10. Keep `PROJECT.md`, `README.md`, `LTI_UPGRADE_PLAN.md`, `LTI13_CANVAS_ROLLOUT_CHECKLIST.md`, and `LESSONS.md` aligned with the current state.

## Current status in this example

The process is still ongoing. The code-heavy part of Phase 1 is documented as complete, but rollout and manual validation are still active. That makes this a good example of documentation evolving from skeleton files, to project context, to an implementation plan, and then further into rollout-specific operational checklists.

## Effort estimate

A rough traditional-development estimate for this body of work would be around **24 to 40 engineering hours** for someone already familiar with the repository and the Canvas/LTI domain.

That estimate includes:

- understanding the existing BFF and launch flow
- writing and revising the planning documents
- implementing dual-mode LTI 1.3 support
- adding or updating tests
- preserving compatibility with existing frontends
- documenting rollout and operational steps

For someone less familiar with the codebase, Canvas setup, or LTI 1.3 migration details, the same work could easily stretch into **40 to 60 hours**. This is only a reasoned guess from the observed scope, not a measured timesheet.

## 8. How this thread was used to build the document

This document was not written in one pass from git history alone. This thread was used in a high-level, iterative way:

1. First, the commit history and the existing markdown files were used to draft the structural story from `b62fdadd` onward.
2. Then you added the human context that git could not show: which models were used, the original prompts, the review and commit loop, the use of `/clear` and `continue`, and the fact that the implementation plan was updated through checkboxes over time.
3. After more commits landed, the history was checked again and the document was extended to include the newer implementation-completion and rollout-checklist commits.
4. The thread also shaped the document by correction: when something important was missing, the document was revised instead of assuming the first draft was complete.

That is part of the usage example too. The markdown was produced through collaboration between repository evidence and human clarification, with the thread acting as the place where missing process details were supplied and the document was refined.
