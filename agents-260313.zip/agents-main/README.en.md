# Agent Template

English translation. The Swedish main version is [README.md](README.md).

A template for projects where you work together with AI agents (Claude Code, Gemini CLI, etc.). I (Alf) collected the files I usually use.

**Source:** [git.lu.se/it/dev/misc/agents](https://git.lu.se/it/dev/misc/agents)

## What Is This?

This repository contains a standardized project structure for working with AI coding agents. The template gives the agent clear context about the project, established conventions, and a structured work plan, which leads to more consistent and predictable behavior. Treat this as a living document rather than a fixed answer key.

## Contents

```
Template/
├── CLAUDE.md      # Entry point for Claude Code (do not edit)
├── AGENTS.md      # Instructions for the agent (git flow, code style, conventions)
├── GEMINI.md      # Entry point for Gemini CLI
├── PROJECT.md     # Architecture, data model, and decisions
├── WORKPLAN.md    # Current status, next steps, and progress
└── LESSONS.md     # Log of lessons from previous sessions
```

- `TEMPLATE_USAGE_EXAMPLE.md` shows how the template evolves in practice: from placeholders to project documentation, a dedicated change plan, incremental implementation, and rollout checklists.

## Getting Started

Copy the `Template/` folder into your new project. Put its contents in the project root.

### In an Existing Project

Ask the agent to update the relevant files to match the actual solution. Example prompt:

```bash
> Look at this solution and the markdown files that we have. Update them accordingly
```

### In a New Project

1. `PROJECT.md` should contain the project's architecture and technical stack. My recommendation is to fill it in together with a CLI agent.
2. `WORKPLAN.md` should reflect the current state, the current focus, and the next logical step. My strong recommendation is not to edit it manually, but to let an agent maintain it through dialogue with you.
3. If the work becomes larger than a few steps, create a separate `*_PLAN.md` for the initiative itself. If the work later moves into rollout or manual verification, also create a `*_CHECKLIST.md` or `*_ROLLOUT_CHECKLIST.md`.
4. Once everything is set up correctly, start the agent. It reads `AGENTS.md` automatically, and from there it can be directed to `PROJECT.md`, `WORKPLAN.md`, and other relevant plan files. Tell it to work.

## Example

See [TEMPLATE_USAGE_EXAMPLE.md](TEMPLATE_USAGE_EXAMPLE.md) for a concrete example of how the template was used in a real repository. That document shows when the base files are enough, when a separate planning document should be created, how the plan can be revised when new facts appear, and how the same documentation later works as the handoff between short agent sessions.

## Philosophy

This is one way to apply a [compound engineering loop](https://every.to/chain-of-thought/compound-engineering-how-every-codes-with-agents), a workflow where each finished iteration makes the next one easier because knowledge accumulates in the project.

The template is a hybrid between **human-in-the-loop** and **human-on-the-loop**. Unlike more autonomous methods such as [Autoresearch](https://github.com/karpathy/autoresearch) or the [Ralph Wiggum technique](https://github.com/ghuntley/how-to-ralph-wiggum), where the agent runs almost independently in loops, you keep clear control over each step. At the same time, there are self-improving elements: the agent reads and writes `LESSONS.md` between sessions, and the project documentation grows iteratively.

What these methods have in common is iterative work, which keeps the context window under control and lets the agent focus on one thing at a time.

- The agent should always have enough context to make the right decision without asking about obvious things.
- Lessons from previous sessions are stored in `LESSONS.md` and loaded into the next session.
- All architectural decisions are documented continuously in `PROJECT.md`.

See also [Inventing the Ralph Wiggum Loop with Geoffrey Huntley](https://www.youtube.com/watch?v=C1YNGy6qusg) for more on the topic.

## Only for Coding?

No. Even though the filenames (`CLAUDE.md`, `WORKPLAN.md`, and so on) and terminology lean toward software development, the structure works just as well for other kinds of projects. The principle is the same: give the agent enough context, a clear plan, and a way to learn over time.

Examples of other use cases:

- **Investigations and reports**: let the agent research, summarize, and draft while you steer the direction.
- **Data analysis**: describe the dataset and the question in `PROJECT.md`, then let the agent propose and run analyses.
- **Documentation**: use the template to keep track of what should be documented and in what order.
- **Process improvement**: describe the current state and the target state, then let the agent suggest improvements step by step.

## Language

I work exclusively in English, but there is no obstacle to asking the agent to always communicate and document in Swedish instead.

## Testing

I strongly recommend that when code is generated, you ask agents to create and run unit tests. Integration tests and end-to-end tests are also valuable when possible. I did not put that directly in the agent file because this template should remain more generic.

## Repo Access

For the agent to be practical in a real workflow, it should be able to work against the repository and the remote service where the repository lives. In this environment, we assume `git.lu.se`.

What matters is that the agent can read history and diffs and help with branches, commits, merge requests, and related repository context when you ask it to.

The exact setup depends on the environment, tooling, and security requirements. A group access token can be a good and controlled option, but this README does not try to document the git or integration setup in detail.

Regardless of method, secrets should stay outside the repository, and the agent can instead be pointed to their location via `AGENTS.md`.

## Security and Warnings

AI agents can run commands, modify files, and make network calls, which means there is a security risk. I work inside a virtual machine, which limits the damage if something goes wrong, but it does not remove all risk. Think carefully about what the agent can access, be cautious about what you whitelist, and always review generated code before it is run or pushed.

The agent file instructs the agent to ask the user before committing and to suggest a commit message. The agent never pushes unless explicitly asked. That gives you control over what is committed and under what message.
