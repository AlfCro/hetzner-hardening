# Agentmall

Svenska är huvudversionen. [English version](README.en.md).

En mall för projekt där man arbetar tillsammans med AI-agenter (Claude Code, Gemini CLI, m.fl.). Jag (Alf) samlade ihop de filer jag brukade använda.

**Källa:** [git.lu.se/it/dev/misc/agents](https://git.lu.se/it/dev/misc/agents)

## Vad är det här?

Det här repot innehåller en standardiserad projektstruktur för att arbeta med AI-kodningsagenter. Mallen ger agenten tydlig kontext om projektet, etablerade konventioner och en strukturerad arbetsplan — vilket leder till mer konsekvent och förutsägbart beteende. Se detta som ett levande dokument mer än som ett facit.

## Innehåll

```
Template/
├── CLAUDE.md      # Startpunkt för Claude Code (redigeras ej)
├── AGENTS.md      # Instruktioner till agenten (git-flöde, kodstil, konventioner)
├── GEMINI.md      # Startpunkt för Gemini CLI
├── PROJECT.md     # Arkitektur, datamodell och beslut
├── WORKPLAN.md    # Aktuell status, nästa steg och framsteg
└── LESSONS.md     # Logg över lärdomar från tidigare sessioner
```

- `TEMPLATE_USAGE_EXAMPLE.md` visar hur mallen utvecklas i praktiken: från platshållare till projektdokumentation, separat förändringsplan, inkrementell implementation och rollout-checklistor.

## Kom igång

Kopiera mappen `Template/` till ditt nya projekt. Lägg innehållen i projektets rot.

### I befintligt projekt

Be agenten att uppdatera innehållet i de relevanta filerna. Och uppdatera dom. Exempelprompt:

```bash
> Look at this solution and the markdown files that we have. Update them accordingly
```

### I nytt projekt

1. Filen `PROJECT.md` bör innehålla projektets arkitektur och tekniska stack. Min rekommendation är att fylla i den tillsammans med en CLI.
2. `WORKPLAN.md` bör spegla nuläge, aktuellt fokus och nästa logiska steg. Min starka rekommendation är att inte redigera den själv utan att du låter en agent göra det i en dialog med dig.
3. Om arbetet blir större än några få steg, skapa en separat `*_PLAN.md` för själva initiativet. Om arbetet sedan går över i utrullning eller manuell verifiering, skapa även en `*_CHECKLIST.md` eller `*_ROLLOUT_CHECKLIST.md`.
4. När allt är korrekt uppsatt, starta agenten — den läser `AGENTS.md` automatiskt och därifrån kan den hänvisas vidare till `PROJECT.md`, `WORKPLAN.md` och andra relevanta planfiler. Säg åt den att arbeta på.

## Exempel

Se [TEMPLATE_USAGE_EXAMPLE.md](TEMPLATE_USAGE_EXAMPLE.md) för ett konkret exempel på hur mallen användes i ett riktigt repo. Det dokumentet visar när grundfilerna räcker, när ett separat plandokument bör skapas, hur planen kan revideras när nya fakta dyker upp, och hur samma dokumentation sedan fungerar som handoff mellan korta agentsessioner.

## Filosofi

Det här är ett sätt att tillämpa en [compound engineering loop](https://every.to/chain-of-thought/compound-engineering-how-every-codes-with-agents) — ett arbetsflöde där varje avslutad iteration gör nästa enklare genom att kunskap ackumuleras i projektet.

Mallen är en hybrid mellan **human-in-the-loop** och **human-on-the-loop**. Till skillnad från mer autonoma metoder som [Autoresearch](https://github.com/karpathy/autoresearch) eller [Ralph Wiggum-tekniken](https://github.com/ghuntley/how-to-ralph-wiggum) — där agenten kör i princip självständigt i loopar — behåller du här tydlig kontroll över varje steg. Samtidigt finns självförbättrande inslag: agenten läser och skriver till `LESSONS.md` mellan sessioner, och projektdokumentationen växer iterativt.

Gemensamt för alla dessa metoder är arbete i iterationer för att hålla nere kontextfönstret och låta agenten fokusera på en sak i taget.

- Agenten ska alltid ha tillräcklig kontext för att fatta rätt beslut utan att fråga om uppenbara saker.
- Lärdomar från tidigare sessioner sparas i `LESSONS.md` och läses in i nästa session.
- Alla arkitekturbeslut dokumenteras i `PROJECT.md` löpande.

Se även [Inventing the Ralph Wiggum Loop with Geoffrey Huntley](https://www.youtube.com/watch?v=C1YNGy6qusg) för mer på ämnet.

## Enbart för kodning?

Nej. Även om filnamnen (`CLAUDE.md`, `WORKPLAN.md` osv.) och terminologin lutar åt mjukvaruutveckling så fungerar strukturen lika bra för andra typer av projekt. Principen är densamma: ge agenten tillräcklig kontext, en tydlig plan och ett sätt att lära sig över tid.

Exempel på andra användningsområden:

- **Utredningar och rapporter** — låt agenten söka, sammanställa och skriva utkast medan du styr riktningen.
- **Dataanalys** — beskriv datasetet och frågeställningen i `PROJECT.md`, låt agenten föreslå och köra analyser.
- **Dokumentation** — använd mallen för att hålla reda på vad som ska dokumenteras och i vilken ordning.
- **Processutveckling** — beskriv nuläge och målbild, låt agenten ta fram förslag på förbättringar steg för steg.

## Språk

Jag arbetar uteslutande på engelska men det finns inget hinder att be agenten att alltid kommunicera och dokumentera på svenska.

## Tester

En stark rekommendation är att när kod ska genereras så uppmana agenterna att skapa och köra enhetstester. Även integrationstester samt End-to-End tester när det är möjligt. Men ville inte lägga in det i agents-filen då denna mall bör ha en mer generisk användning.

## Repo-åtkomst

För att agenten ska vara praktisk i ett riktigt arbetsflöde bör den kunna arbeta mot repot och mot den fjärrtjänst där repot ligger. I den här miljön utgår vi från `git.lu.se`.

Det viktiga är att agenten kan läsa historik och diffar och vid behov hjälpa till med brancher, commits, merge requests och annan repo-kontext när du ber om det.

Exakt lösning beror på miljö, verktyg och säkerhetskrav. En group access token kan vara ett bra och kontrollerat alternativ, men den här README:n försöker inte dokumentera själva git- eller integrationsuppsättningen i detalj.

Oavsett metod bör hemligheter hållas utanför repot och agenten kan i stället hänvisas till deras plats via `AGENTS.md`.

## Säkerhet och varningar

AI-agenter kan köra kommandon, ändra filer och göra nätverksanrop vilket innebär en säkerhetsrisk. Jag arbetar i en virtuell maskin vilket begränsar skadan om något går fel, men det eliminerar inte alla risker. Tänk igenom vad agenten har åtkomst till, var försiktig med vad du vitlistar och granska alltid genererad kod innan den körs eller pushas.

I agents-filen ges riktlinjen att agenten frågar användaren innan den committar och föreslår ett commit-meddelande. Agenten pushar aldrig utan att bli ombedd. Det ger dig kontroll över vad som committas och med vilken kommentar.
